### Run fastmixture for K=2,3 and three different seeds
for k in {2,3}
do
	for s in {1..3}
	do
		fastmixture --bfile sim.small --K $k --threads 10 --seed $s --out sim.small
	done
done
# Saves three files for each run (.Q, .P and .log)

### Plot results and save (using R)
for k in {2,3}
do
	for s in {1..3}
	do
		Rscript plotAdmixture.R sim.small.K${k}.s${s}.Q
	done
done
